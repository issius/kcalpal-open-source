import { createHash } from 'node:crypto'
import { readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
export const patchManifest = JSON.parse(await readFile(path.join(here, 'camera-preview-8.11.6.patch.json'), 'utf8'))
const digest = text => createHash('sha256').update(text).digest('hex')

/** Only the exact published 8.11.6 sources or their exact patched forms are accepted. */
export async function patchCameraPreview(packageRoot) {
  const packageInfo = JSON.parse(await readFile(path.join(packageRoot, 'package.json'), 'utf8'))
  if (packageInfo.name !== patchManifest.packageName || packageInfo.version !== patchManifest.version) {
    throw new Error(`Camera preview patch requires ${patchManifest.packageName}@${patchManifest.version}; review the patch before changing versions.`)
  }

  // Validate every file before any write, so source drift never leaves a partial patch.
  const pending = []
  for (const file of patchManifest.files) {
    const target = path.join(packageRoot, file.path)
    const original = await readFile(target, 'utf8')
    const currentHash = digest(original)
    if (currentHash === file.afterSha256) continue
    let updated = original
    if (currentHash !== file.beforeSha256) {
      const previousPatch = file.acceptedPreviousPatches?.find(previous => previous.sha256 === currentHash)
      if (!previousPatch) {
        throw new Error(`Camera preview source drift: ${file.path}. No patch was applied.`)
      }
      // An upgrade starts only from an exact known patched source. Reverse its
      // frozen hunks and verify the published source before applying current ones.
      for (const replacement of [...previousPatch.replacements].reverse()) {
        if (updated.split(replacement.after).length !== 2) {
          throw new Error(`Camera preview upgrade anchor must match exactly once: ${file.path}`)
        }
        updated = updated.replace(replacement.after, () => replacement.before)
      }
      if (digest(updated) !== file.beforeSha256) {
        throw new Error(`Camera preview upgrade source mismatch: ${file.path}`)
      }
    }
    for (const replacement of file.replacements) {
      if (updated.split(replacement.before).length !== 2) {
        throw new Error(`Camera preview patch anchor must match exactly once: ${file.path}`)
      }
      updated = updated.replace(replacement.before, () => replacement.after)
    }
    if (digest(updated) !== file.afterSha256) {
      throw new Error(`Camera preview patch result mismatch: ${file.path}`)
    }
    pending.push({ target, updated })
  }

  for (const { target, updated } of pending) await writeFile(target, updated, 'utf8')
  return { changedFiles: pending.length, version: patchManifest.version }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const packageRoot = path.resolve(here, '../../node_modules/@capgo/camera-preview')
  try {
    const result = await patchCameraPreview(packageRoot)
    console.log(`Camera preview ${result.version}: still-photo patch verified (${result.changedFiles} files updated).`)
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error))
    process.exitCode = 1
  }
}
